PROYECTO QGIS - PERIURBANO OESTE DE MAR DEL PLATA

Este archivo contiene el proyecto QGIS utilizado para el desarrollo de la tesis doctoral titulada "Gestión Integrada de Recursos Hídricos (GIRH) en el periurbano oeste del Partido de General Pueyrredon. Alternativas para contribuir a la gobernanza del agua".


REQUISITOS:
- QGIS 3.34 o superior (https://qgis.org/)
- No se necesita conexión a base de datos; los datos están en formato shapefile.

CONTENIDO:
- proyecto.qgz: archivo del proyecto QGIS.
- /capas: carpeta con archivos shapefile (.shp, .dbf, .shx, etc.)
- /tablas: CSV con datos utilizados en análisis.
- Todos los caminos son relativos, por lo que solo hay que descomprimir el .zip y abrir el .qgz desde QGIS.

LICENCIA:
Este material puede ser utilizado con fines educativos, de gestión y de investigación. Citar fuente.

CONTACTO:
Lic. María José Martín Velasco - [martinvelascomariajose@gmail.com]
